﻿using DaysCalculatorProject.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DaysCalculatorProject.Controllers
{
    public class HomeController : Controller
    {
        List<NavBarModules> ModulesList = new List<NavBarModules>()
        {
            new NavBarModules {ModuleId = 1,ModuleName = "Count Days", PartialViewName = "_CountDays"},
            new NavBarModules {ModuleId = 2,ModuleName = "Add Days",PartialViewName = "_AddDays"},
            new NavBarModules {ModuleId = 3,ModuleName = "Work Days", PartialViewName = "_WorkDays"},
            new NavBarModules {ModuleId = 4,ModuleName = "Add WorkDays", PartialViewName = "_AddWorkDays"},
            new NavBarModules {ModuleId = 5,ModuleName = "Week Day", PartialViewName = "_WeekDay"},
            new NavBarModules {ModuleId = 6,ModuleName = "Week No.", PartialViewName = "_WeekNo"}
        };


        // GET: Home
        public ActionResult Index()
        {
            return View(ModulesList);
        }

        public JsonResult GetHolidayList()
        {
            List<Holiday> HolidayList = new List<Holiday>()
            {
                new Holiday {HolidayId = 1,HolidayName = "Makar Sankranti, Uttarayan",HolidayDate = 14, HolidayMonth = 01, HolidayYear = 2023,HolidayJulianDay = 14,HolidayIsActive = true },
                new Holiday {HolidayId = 2,HolidayName = "Vasi Uttrayan",HolidayDate = 15, HolidayMonth = 01, HolidayYear = 2023,HolidayJulianDay = 15,HolidayIsActive = true },
                new Holiday {HolidayId = 3,HolidayName = "Republic Day",HolidayDate = 26, HolidayMonth = 01, HolidayYear = 2023,HolidayJulianDay = 26,HolidayIsActive = true },
                new Holiday {HolidayId = 4,HolidayName = "Holi",HolidayDate = 08, HolidayMonth = 03, HolidayYear = 2023,HolidayJulianDay = 26,HolidayIsActive = true },
                new Holiday {HolidayId = 5,HolidayName = "Independence Day",HolidayDate = 15, HolidayMonth = 08, HolidayYear = 2023,HolidayJulianDay = 227,HolidayIsActive = true },
                new Holiday {HolidayId = 6,HolidayName = "Raksha Bandhan",HolidayDate = 30, HolidayMonth = 08, HolidayYear = 2023,HolidayJulianDay = 242,HolidayIsActive = true },
                new Holiday {HolidayId = 7,HolidayName = "Gandhi Jayanti",HolidayDate = 02, HolidayMonth = 10, HolidayYear = 2023,HolidayJulianDay = 275,HolidayIsActive = true },
                new Holiday {HolidayId = 8,HolidayName = "Dusshera",HolidayDate = 24, HolidayMonth = 10, HolidayYear = 2023,HolidayJulianDay = 297,HolidayIsActive = true },
                new Holiday {HolidayId = 9,HolidayName = "Diwali",HolidayDate = 12, HolidayMonth = 11, HolidayYear = 2023,HolidayJulianDay = 316,HolidayIsActive = true },
                new Holiday {HolidayId = 10,HolidayName = "New Year",HolidayDate = 13, HolidayMonth = 11, HolidayYear = 2023,HolidayJulianDay = 317,HolidayIsActive = true },
                new Holiday {HolidayId = 11,HolidayName = "Bhai Duj",HolidayDate = 14, HolidayMonth = 11, HolidayYear = 2023,HolidayJulianDay = 318,HolidayIsActive = true },
                new Holiday {HolidayId = 12,HolidayName = "Treej",HolidayDate = 15, HolidayMonth = 11, HolidayYear = 2023,HolidayJulianDay = 319,HolidayIsActive = true },
                new Holiday {HolidayId = 13,HolidayName = "Chauth",HolidayDate = 16, HolidayMonth = 11, HolidayYear = 2023,HolidayJulianDay = 320,HolidayIsActive = true },

            };
            return Json(HolidayList, JsonRequestBehavior.AllowGet);
        }

        public ActionResult LoadPartialViewByName(string pPartialView)
        {
            return PartialView(pPartialView);
            //return View("_CountDays");
        }

	
        
       
    }
}