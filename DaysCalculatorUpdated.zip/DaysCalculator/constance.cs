﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DaysCalculatorProject
{
    public static class constance
    {
#if DEBUG
        public const string BaseUrl = "https://localhost:44397";
#else
        public const string BaseUrl = "http://192.168.1.110:99";
#endif
    }
}