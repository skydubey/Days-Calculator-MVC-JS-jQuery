﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DaysCalculatorProject.Models
{
    public class Holiday
    {
        public int HolidayId { get; set; }
        public int HolidayDate { get; set; }
        public int HolidayMonth { get; set; }
        public int HolidayYear { get; set; }
        public string HolidayName { get; set; }
        public int HolidayJulianDay { get; set; }
        public bool HolidayIsActive { get; set; }
    }
}