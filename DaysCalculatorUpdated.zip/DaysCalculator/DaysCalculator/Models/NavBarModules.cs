﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DaysCalculatorProject.Models
{
    public class NavBarModules
    {
       
        public int ModuleId { get; set; }
        public string ModuleName { get; set; }
        public string PartialViewName { get; set; }

    }
}