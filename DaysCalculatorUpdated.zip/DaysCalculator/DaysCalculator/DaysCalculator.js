﻿const daysNames = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
const monthNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
//const holidayDates1 = [new Date(2023, 0, 14), new Date(2023, 0, 15), new Date(2023, 0, 26), new Date(2023, 2, 08), new Date(2023, 7, 15), new Date(2023, 7, 30), new Date(2023, 9, 02), new Date(2023, 9, 24), new Date(2023, 10, 12), new Date(2023, 10, 13), new Date(2023, 10, 14), new Date(2023, 10, 15), new Date(2023, 10, 16)];
let holidayDates = [];
var holidaysArray = [1, 2, 3, 4];

//#region Ajax Call to get Holiday List 
HolidayListValueGetter();
function HolidayListValueGetter() {

    $.ajax({
        url: UrlPath + '/Home/GetHolidayList',
        type: 'GET',
        dataType: 'json',
        success: function (data) {
            for (var i = 0; i < data.length; i++) {
                holidayDates[i] = new Date(data[i].HolidayYear, data[i].HolidayMonth - 1, data[i].HolidayDate);
            }
        },
    })
}
//#endregion

let PartialViewname; // For Detecting PartialViewName of PartialView to Run its Function.

function MainFunction(PartialViewname) {

    //#region All Value Reset

    $("#fromstring").text("");
    $("#tostring").text("");
    $("#daysDiff").text("");
    $("#diffSecs").text("");
    $("#diffMins").text("");
    $("#diffHours").text("");
    $("#diffWeeks").text("");

    //#endregion

    //#region All Variables

    let startdateinput = document.getElementById("startdatepicker"); // StartDate Input
    let enddateinput = document.getElementById("enddatepicker");     // EndDate Input

    let date1 = new Date(startdateinput.value); //Convert Start Date Input into Date Object.

    let startDate = date1.getDate();            // return Start Date only like dd in dd/mm/yyyy format. 
    let startMonth = date1.getMonth() + 1;      // return Start Month only like mm in dd/mm/yyyy format. 
    let startYear = date1.getFullYear();        // return Start year only like yyyy in dd/mm/yyyy format.
    let startHours = date1.getHours();          // return Start Hours of Time Selection.
    let startMins = date1.getMinutes();         // return Start Minutes of Time Selection.

    let intStartDay = date1.getDay();       // StartDate in Number Format like 0 for Sunday and 1 for Monday.
    let intStartMonth = date1.getMonth();   // StartMonth in Number Format like 0 for January and 11 for December.

    // This is a String to Print From Date & To Date on the View.
    let fromString = "From - " + daysNames[intStartDay] + "," + startDate + " " + monthNames[intStartMonth] + " " + startYear + " -  " + startHours + ":" + startMins;



    let date2 = new Date(enddateinput.value);   //Convert Start Date Input into Date Object.

    let endDate = date2.getDate();              // return End Date only like dd in dd/mm/yyyy format.
    let endMonth = date2.getMonth() + 1;        // return End Month only like mm in dd/mm/yyyy format.
    let endYear = date2.getFullYear();          // return Start Year only like yyyy in dd/mm/yyyy format.
    let endHours = date2.getHours();            // return End Hours of Time Selection.     
    let endMins = date2.getMinutes();           // return End Minutes of Time Selection.


    let intEndDay = date2.getDay();         // EndDate in Number Format like 0 for Sunday and 1 for Monday.
    let intEndMonth = date2.getMonth();     // EndMonth in Number Format like 0 for January and 11 for December.

    let toString = "To - " + daysNames[intEndDay] + "," + endDate + " " + monthNames[intEndMonth] + " " + endYear + "  -  " + endHours + ":" + endMins;

    // All Difference of Seconds, Minutes, Hours, Days, Weeks.

    let diffSecs = getSecsDiff(date1, date2);
    let diffMins = getMinsDiff(diffSecs);
    let diffHours = getHoursDiff(diffMins);
    let diffDays = getDaysDiff(diffHours);
    let diffWeeks = getWeeksDiff(diffDays);

    //#endregion

    //#region Functions to Calculate Different Units

    function getDaysDiff(diffHours) {
        return Math.round(Math.abs(diffHours / 24));

    }

    function getSecsDiff(date1, date2) {
        return Math.round((date2.getTime() - date1.getTime()) / 1000);
    }

    function getMinsDiff(diffSecs) {
        return Math.round(Math.abs(diffSecs / 60));
    }

    function getHoursDiff(diffMins) {
        return Math.round(Math.abs(diffMins / 60));
    }

    function getWeeksDiff(diffDays) {
        return Math.round(Math.abs(diffDays / 7));
    }

    //#endregion 

    //#region Basic Logics and Functions

    function ToRemoveDiffDays() {

        if (diffDays < 1) {
            $("#DaysDiffDisplay").addClass("d-none");
            $("#checktodaydate").addClass("d-none");
            $("#checktodaydatelabel").addClass("d-none");
        }
        else {
            console.log();
        }

    }

    function ExcludeWeekendDays() {
        /*let intStartDay = date1.getDay();       // StartDate in Number Format like 0 for Sunday and 1 for Monday.
        let intEndDay = date2.getDay();         // EndDate in Number Format like 0 for Sunday and 1 for Monday.*/
        if (document.getElementById("excludeweekend").checked == 1) {

            var weekends = diffWeeks * 2;
            diffDays = diffDays - weekends;
            if (intStartDay - intEndDay > 1) {
                diffDays = diffDays - 2;
            }
            // Remove start day if span starts on Sunday but ends before Saturday
            if (intStartDay == 0 && intEndDay != 6) {
                diffDays = diffDays - 1;
            }
            // Remove end day if span ends on Saturday but starts after Sunday
            if (intEndDay == 6 && intStartDay != 0) {
                diffDays = diffDays - 1;
                $("#daysDiff").text(diffDays);
            }
            else {
                console.log();
            }
            return diffDays;

        }
        else {
            console.log();
        }
    }

    function CheckTodayDate() {

        // To Reset (d-none) classes by deafult to avoid error.
        $("#DaysDiffDisplay").removeClass("d-none");
        $("#checktodaydate").removeClass("d-none");
        $("#checktodaydatelabel").removeClass("d-none");

        // To Add End Date In Calculation.
        if (document.getElementById("checktodaydate").checked) {
            diffDays += 1;
        }
        else {
            diffDays = diffDays + 0;
        }

        return diffDays;
    }

    function ExcludeHoliday() {

        if (document.getElementById("excludeholidays").checked == 1) {

            var count1 = 0;
            var count2 = 0;
            //ajax call
            //holiday list

            for (var i = 0; i < holidayDates.length; i++) {

                if (holidayDates[i] >= date1 && holidayDates[i] <= date2) {
                    if (holidayDates[i].getDay() == 0 || holidayDates[i].getDay() == 6) {
                        count2++;
                    }

                    else {
                        console.log(holidayDates[i] + "This date is in between date 1 and date 2");
                        count1++;
                    }
                }
                else {
                    console.log("Not Found");
                }
            }
            console.log(count1); // without weekend  holidays
            console.log(count2); // overlap weekend holidays
            var totalholidays = count1 + count2;

            if (document.getElementById("excludeweekend").checked == 1) {
                return diffDays = diffDays - count1;
            }
            else {
                return diffDays = diffDays - totalholidays;
            }

        }
        else {
            console.log();
        }
    }

    //#endregion  

    //#region Call Module Functions

    ModuleFunctionCaller(PartialViewname);
    function ModuleFunctionCaller() {

        if (PartialViewname == _CountDays) {
            CountDays();
            PartialViewname = "";
        }
        else if (PartialViewname == _WorkDays) {
            WorkDays();
        }
        else if (PartialViewname == _AddDays) {
            AddDays();
        }
        else alert("Partial View Not Found");
    }
    //#endregion

    //#region All Module Seperate Functions

    function CountDays() {
        // CountDays Function - Module 1

        if (date1 > date2) {

            Swal.fire({
                icon: 'error',
                title: 'Oops...',
                html: '<div><h3>Please Enter Date Correctly!</h3><small style="color:red;">Start Date Cannot be Greater than End Date!</small></div>',
                //html: '',
            })
        }

        else {

            if ((startdateinput.value != "" && enddateinput.value != "")) {

                CheckTodayDate();
                //ToRemoveDiffDays();

                diffSecs += (((diffDays * 24) * 60) * 60);
                diffMins = getMinsDiff(diffSecs);
                diffHours = getHoursDiff(diffMins);
                diffWeeks = getWeeksDiff(diffDays);

                $("#fromstring").text(fromString);
                $("#tostring").text(toString);
                $("#daysDiff").text(diffDays);

                $("#diffSecs").text(Math.round(diffSecs) + " Seconds");
                $("#diffMins").text(diffMins + " Minutes");
                $("#diffHours").text(diffHours + " Hours");
                $("#diffWeeks").text(diffWeeks + " Weeks");

                $("#result").removeClass("d-none");
                window.scrollTo(0, 700);
                diffDays = 0;
            }

            else {
                $("#fromstring").text("");
                $("#tostring").text("");
            }
        }

    }

    function WorkDays() {
        // WorkDays Function - Module 2

        if (date1 > date2) {

            Swal.fire({
                icon: 'error',
                title: 'Oops...',
                html: '<div><h3>Please Enter Date Correctly!</h3><small style="color:red;">Start Date Cannot be Greater than End Date!</small></div>',
                //html: '',
            })
        }

        else {

            if ((startdateinput.value != "" && enddateinput.value != "")) {

                CheckTodayDate();
                //ToRemoveDiffDays();
                ExcludeWeekendDays();
                ExcludeHoliday();

                diffSecs += (((diffDays * 24) * 60) * 60);
                diffMins = getMinsDiff(diffSecs);
                diffHours = getHoursDiff(diffMins);
                diffWeeks = getWeeksDiff(diffDays);

                $("#fromstring").text(fromString);
                $("#tostring").text(toString);
                $("#daysDiff").text(diffDays);

                $("#diffSecs").text(Math.round(diffSecs) + " Seconds");
                $("#diffMins").text(diffMins + " Minutes");
                $("#diffHours").text(diffHours + " Hours");
                $("#diffWeeks").text(diffWeeks + " Weeks");

                $("#result").removeClass("d-none");
                window.scrollTo(0, 760);
                diffDays = 0;
            }

            else {
                $("#fromstring").text("");
                $("#tostring").text("");
            }
        }

    }

    //#endregion

}


let _PartialViewName2; // For Detecting PartialViewName of PartialView to Run its Function.
function MainFunction2(_PartialViewName2) {

    //#region Common Function and Variables

    let startdateinput = document.getElementById("startdatepicker"); // StartDate Input
    let date1 = new Date(startdateinput.value); //Convert Start Date Input into Date Object.

    let startDate = date1.getDate();            // return Start Date only like dd in dd/mm/yyyy format. 
    let startMonth = date1.getMonth() + 1;      // return Start Month only like mm in dd/mm/yyyy format. 
    let startYear = date1.getFullYear();        // return Start year only like yyyy in dd/mm/yyyy format.
    let startHours = date1.getHours();          // return Start Hours of Time Selection.
    let startMins = date1.getMinutes();         // return Start Minutes of Time Selection.

    let intStartDay = date1.getDay();       // StartDate in Number Format like 0 for Sunday and 1 for Monday.
    let intStartMonth = date1.getMonth();   // StartMonth in Number Format like 0 for January and 11 for December.

    // This is a String to Print From Date & To Date on the View.
    let fromString = "From - " + daysNames[intStartDay] + "," + startDate + " " + monthNames[intStartMonth] + " " + startYear + " -  " + startHours + ":" + startMins;


    let numOfDays = document.getElementById("inputdaysadd").value;

    let addOrSubtract = document.getElementById("addorsubtract").value;


    // Add Days, Months, Years Function.
    function addDays(date1, days) {
        date1.setDate(date1.getDate() + days);
        return date1;
    }

    function addMonths(date1, months) {
        date1.setMonth(date1.getMonth() + months);
        return date1;
    }

    function addYears(date1, years) {
        date1.setFullYear(date1.getFullYear() + years);
        return date1;
    }

    // Subtract Days, Months, Years Function.
    function subDays(date1, days) {
        //numOfDays++;
        date1.setDate(date1.getDate() - days);
        return date1;
    }

    function subMonths(date1, months) {
        date1.setMonth(date1.getMonth() - months);
        return date1;
    }

    function subYears(date1, years) {
        date1.setFullYear(date1.getFullYear() - years);
        return date1;
    }

    //#endregion 

    //#region Functions to Calculate Different Units

    function getDaysDiff(diffHours) {
        return Math.round(Math.abs(diffHours / 24));

    }

    function getSecsDiff(date1, date2) {
        return Math.round((date2.getTime() - date1.getTime()) / 1000);
    }

    function getMinsDiff(diffSecs) {
        return Math.round(Math.abs(diffSecs / 60));
    }

    function getHoursDiff(diffMins) {
        return Math.round(Math.abs(diffMins / 60));
    }

    function getWeeksDiff(diffDays) {
        return Math.round(Math.abs(diffDays / 7));
    }

    //#endregion 

    //#region Basic Logics and Functions

    function ToRemoveDiffDays() {

        if (diffDays < 1) {
            $("#DaysDiffDisplay").addClass("d-none");
            $("#checktodaydate").addClass("d-none");
            $("#checktodaydatelabel").addClass("d-none");
        }
        else {
            console.log();
        }

    }

    function ExcludeWeekendDays(date1, date2, diffDays, diffWeeks) {
        let intStartDay = date1.getDay();       // StartDate in Number Format like 0 for Sunday and 1 for Monday.
        let intEndDay = date2.getDay();         // EndDate in Number Format like 0 for Sunday and 1 for Monday.
        if (document.getElementById("excludeweekend").checked == 1) {

            var weekends = diffWeeks * 2;
            diffDays = diffDays - weekends;
            if (intStartDay - intEndDay > 1) {
                diffDays = diffDays - 2;
            }
            // Remove start day if span starts on Sunday but ends before Saturday
            if (intStartDay == 0 && intEndDay != 6) {
                diffDays = diffDays - 1;
            }
            // Remove end day if span ends on Saturday but starts after Sunday
            if (intEndDay == 6 && intStartDay != 0) {
                diffDays = diffDays - 1;
                $("#daysDiff").text(diffDays);
            }
            else {
                console.log();
            }
            return diffDays;

        }
        else {
            console.log();
        }
    }

    function CheckTodayDate() {

        // To Reset (d-none) classes by deafult to avoid error.
        $("#DaysDiffDisplay").removeClass("d-none");
        $("#checktodaydate").removeClass("d-none");
        $("#checktodaydatelabel").removeClass("d-none");

        // To Add End Date In Calculation.
        if (document.getElementById("checktodaydate").checked) {
            diffDays += 1;
        }
        else {
            diffDays = diffDays + 0;
        }

        return diffDays;
    }

    function ExcludeHoliday(date1, date2, diffDays) {
        debugger;
        if (document.getElementById("excludeholidays").checked == 1) {

            var count1 = 0;
            var count2 = 0;
            //ajax call
            //holiday list

            for (var i = 0; i < holidayDates.length; i++) {

                if (holidayDates[i] >= date1 && holidayDates[i] <= date2) {
                    if (holidayDates[i].getDay() == 0 || holidayDates[i].getDay() == 6) {
                        count2++;
                    }

                    else {
                        //console.log(holidayDates[i] + "This date is in between date 1 and date 2");
                        count1++;
                    }
                }
                else {
                    //console.log("Not Found");
                }
            }
            //console.log(count1); // without weekend  holidays
            //console.log(count2); // overlap weekend holidays
            var totalholidays = count1 + count2;

            if (document.getElementById("excludeweekend").checked == 1) {
                return diffDays = diffDays - count1;
            }
            else {
                return diffDays = diffDays - totalholidays;
            }

        }
        else {
            //console.log();
        }
    }

    //#endregion

    //#region Call Module Functions

    ModuleFunctionCaller2(_PartialViewName2);
    function ModuleFunctionCaller2(_PartialViewName2) {

        if (_PartialViewName2 == _AddDays) {
            AddDays();
            //_PartialViewName2 = "";
        }
        else if (_PartialViewName2 == _AddWorkDays) {
            AddWorkDays();
            //_PartialViewName2 = "";
        }
        else if (_PartialViewName2 == _WeekDay) {
            WeekDay();
            //_PartialViewName2 = "";
        }
        else if (_PartialViewName2 == _WeekNo) {
            WeekNo();
            //_PartialViewName2 = "";
        }

        else alert("Partial View Not Found");
    }

    //#endregion

    //#region All Module Seperate Functions
    // Module no. 3 - Add Days.
    function AddDays() {
        // AddDays Function - Module 2

        var numOfMonths = document.getElementById("inputmonthsadd").value;
        var numOfYears = document.getElementById("inputyearsadd").value;



        if (startdateinput.value != "") {

            if ((numOfDays == "" || numOfMonths == "" || numOfYears == ""))
                Swal.fire({
                    icon: 'error',
                    title: 'Oops...',
                    html: '<div><h3>Please Enter All fields of Days, Months & Year!</h3><small style="color:red;">All fields are necessary!</small></div>',
                    //html: '',
                })

            else {

                if (addOrSubtract == 1) {

                    $("#fromstring").text("");
                    $("#tostring").text("");
                    $("#detailsofadd").text("");
                    $("#totaldaysresult").text("");

                    const addNewDate = addYears(date1, parseInt(numOfYears));
                    const addNewDate2 = addMonths(date1, parseInt(numOfMonths));
                    const addNewDate3 = addDays(date1, parseInt(numOfDays));

                    let endDate = addNewDate3.getDate();            // return Start Date only like dd in dd/mm/yyyy format. 
                    let endMonth = addNewDate3.getMonth() + 1;      // return Start Month only like mm in dd/mm/yyyy format. 
                    let endYear = addNewDate3.getFullYear();        // return Start year only like yyyy in dd/mm/yyyy format.
                    let endHours = addNewDate3.getHours();          // return Start Hours of Time Selection.
                    let endMins = addNewDate3.getMinutes();         // return Start Minutes of Time Selection.

                    let intEndDay = addNewDate3.getDay();       // StartDate in Number Format like 0 for Sunday and 1 for Monday.
                    let intEndMonth = addNewDate3.getMonth();   // StartMonth in Number Format like 0 for January and 11 for December.


                    let toString = "To - " + daysNames[intEndDay] + "," + endDate + " " + monthNames[intEndMonth] + " " + endYear + "  -  " + endHours + ":" + endMins;
                    let detailofaddorsub = " Added => " + numOfDays + " Days, " + numOfMonths + " Months, " + numOfYears + " Years. "
                    let totalresult = daysNames[intEndDay] + "," + endDate + " " + monthNames[intEndMonth] + " " + endYear;
                    $("#fromstring").text(fromString);
                    $("#tostring").text(toString);
                    $("#detailsofaddorsub").text(detailofaddorsub);
                    $("#totaldaysresult").text(totalresult);




                    $("#result").removeClass("d-none");
                    window.scrollTo(0, 760);

                }

                else {

                    $("#fromstring").text("");
                    $("#tostring").text("");
                    $("#detailsofaddorsub").text("");
                    $("#totaldaysresult").text("");

                    const subNewDate = subYears(date1, parseInt(numOfYears));
                    const subNewDate2 = subMonths(date1, parseInt(numOfMonths));
                    const subNewDate3 = subDays(date1, parseInt(numOfDays));


                    let endDate = subNewDate3.getDate();            // return Start Date only like dd in dd/mm/yyyy format. 
                    let endMonth = subNewDate3.getMonth() + 1;      // return Start Month only like mm in dd/mm/yyyy format. 
                    let endYear = subNewDate3.getFullYear();        // return Start year only like yyyy in dd/mm/yyyy format.
                    let endHours = subNewDate3.getHours();          // return Start Hours of Time Selection.
                    let endMins = subNewDate3.getMinutes();         // return Start Minutes of Time Selection.

                    let intEndDay = subNewDate3.getDay();       // StartDate in Number Format like 0 for Sunday and 1 for Monday.
                    let intEndMonth = subNewDate3.getMonth();   // StartMonth in Number Format like 0 for January and 11 for December.


                    let toString2 = "To - " + daysNames[intEndDay] + "," + endDate + " " + monthNames[intEndMonth] + " " + endYear + "  -  " + endHours + ":" + endMins;
                    let detailofaddorsub2 = " Subtracted => " + numOfDays + " Days, " + numOfMonths + " Months, " + numOfYears + " Years. "
                    let totalresult2 = daysNames[intEndDay] + "," + endDate + " " + monthNames[intEndMonth] + " " + endYear;

                    $("#fromstring").text(fromString);
                    $("#tostring").text(toString2);
                    $("#detailsofaddorsub").text(detailofaddorsub2);
                    $("#totaldaysresult").text(totalresult2);

                    $("#result").removeClass("d-none");
                    window.scrollTo(0, 760);

                }
            }
        }
    }

    // Module no. 4 - AddWorkDays Days.

    function AddWorkDays() {



        //#region 1st TRY
        //1st If
        if (startdateinput.value == "" || numOfDays == "") {
            Swal.fire({
                icon: 'error',
                title: 'Oops...',
                html: '<div><h3>Please Enter Date & Days to Add!</h3><small style="color:red;">Date & Days fiels cannot be blank!</small></div>',
                //html: '',
            })
        }

        //1st Else
        else {

            if ((document.getElementById("excludeweekend").checked == 1)) {

                if (addOrSubtract == 1) {

                    $("#fromstring").text("");
                    $("#tostring").text("");
                    $("#detailsofaddorsub").text("");
                    $("#totaldaysresult").text("");
                    $("#fromstring").text(fromString);

                    //const addNewDate3 = addDays(date1, parseInt(numOfDays));
                    function ExcludeWeekend(date1, n) {
                        addDays(date1, 1);

                        //debugger;
                        let count = 0;
                        for (var i = 0; i < i < n * 1.5; i++) {
                            if ((date1.getDay() == 0) || (date1.getDay() == 6)) {
                                if (holidayDates.includes(date1, 0) == true) {

                                }
                                addDays(date1, 1);
                            }
                            else {
                                count++;
                                if (count == n) {

                                    let endDate = date1.getDate();            // return Start Date only like dd in dd/mm/yyyy format. 
                                    let endMonth = date1.getMonth() + 1;      // return Start Month only like mm in dd/mm/yyyy format. 
                                    let endYear = date1.getFullYear();        // return Start year only like yyyy in dd/mm/yyyy format.
                                    let endHours = date1.getHours();          // return Start Hours of Time Selection.
                                    let endMins = date1.getMinutes();         // return Start Minutes of Time Selection.

                                    let intEndDay = date1.getDay();       // StartDate in Number Format like 0 for Sunday and 1 for Monday.
                                    let intEndMonth = date1.getMonth();   // StartMonth in Number Format like 0 for January and 11 for December.

                                    let toString = "To - " + daysNames[intEndDay] + "," + endDate + " " + monthNames[intEndMonth] + " " + endYear + "  -  " + endHours + ":" + endMins;
                                    let detailofaddorsub = " Added => " + numOfDays + " Business Days. ";
                                    let totalresult = daysNames[intEndDay] + "," + endDate + " " + monthNames[intEndMonth] + " " + endYear;

                                    $("#tostring").text(toString);
                                    $("#detailsofaddorsub").text(detailofaddorsub);
                                    $("#totaldaysresult").text(totalresult);

                                    return date1;
                                }
                                addDays(date1, 1);
                            }
                        }
                    }
                    ExcludeWeekend(date1, numOfDays);

                    $("#result").removeClass("d-none");
                    window.scrollTo(0, 760);

                }

                else {

                    $("#fromstring").text("");
                    $("#tostring").text("");
                    $("#detailsofaddorsub").text("");
                    $("#totaldaysresult").text("");
                    $("#fromstring").text(fromString);


                    //const addNewDate3 = addDays(date1, parseInt(numOfDays));
                    function ExcludeWeekend(date1, n) {
                        let count = 0;
                        for (var i = 0; n * 1.5; i++) {
                            if ((date1.getDay() == 0) || (date1.getDay() == 6) || (holidayDates.includes(date1) == true)) {
                                subDays(date1, 1);
                            }
                            else {
                                count++;
                                if (count == n) {

                                    let endDate = date1.getDate();            // return Start Date only like dd in dd/mm/yyyy format. 
                                    let endMonth = date1.getMonth() + 1;      // return Start Month only like mm in dd/mm/yyyy format. 
                                    let endYear = date1.getFullYear();        // return Start year only like yyyy in dd/mm/yyyy format.
                                    let endHours = date1.getHours();          // return Start Hours of Time Selection.
                                    let endMins = date1.getMinutes();         // return Start Minutes of Time Selection.

                                    let intEndDay = date1.getDay();       // StartDate in Number Format like 0 for Sunday and 1 for Monday.
                                    let intEndMonth = date1.getMonth();   // StartMonth in Number Format like 0 for January and 11 for December.




                                    let toString = "To - " + daysNames[intEndDay] + "," + endDate + " " + monthNames[intEndMonth] + " " + endYear + "  -  " + endHours + ":" + endMins;
                                    let detailofaddorsub = " Subtracted => " + numOfDays + " Business Days. ";
                                    let totalresult = daysNames[intEndDay] + "," + endDate + " " + monthNames[intEndMonth] + " " + endYear;

                                    $("#tostring").text(toString);
                                    $("#detailsofaddorsub").text(detailofaddorsub);
                                    $("#totaldaysresult").text(totalresult);
                                    return date1;
                                }
                                subDays(date1, 1);
                            }
                        }
                    }

                    ExcludeWeekend(date1, numOfDays);

                    $("#result").removeClass("d-none");
                    window.scrollTo(0, 760);

                }


            }

            else if (document.getElementById("excludeholidays").checked == 1) {

                if (addOrSubtract == 1) {

                    $("#fromstring").text("");
                    $("#tostring").text("");
                    $("#detailsofaddorsub").text("");
                    $("#totaldaysresult").text("");
                    $("#fromstring").text(fromString);

                    //const addNewDate3 = addDays(date1, parseInt(numOfDays));
                    function ExcludeWeekend(date1, n) {
                        console.log("Yeh raha tumhara date 1 - " + date1);
                        let count = 0;
                        for (var i = 0; i < n * 1.5; i++) {
                            if ((holidayDates.includes(date1) == true)) {
                                addDays(date1, 1);
                            }
                            else {
                                count++;
                                if (count == n) {

                                    let endDate = date1.getDate();            // return Start Date only like dd in dd/mm/yyyy format. 
                                    let endMonth = date1.getMonth() + 1;      // return Start Month only like mm in dd/mm/yyyy format. 
                                    let endYear = date1.getFullYear();        // return Start year only like yyyy in dd/mm/yyyy format.
                                    let endHours = date1.getHours();          // return Start Hours of Time Selection.
                                    let endMins = date1.getMinutes();         // return Start Minutes of Time Selection.

                                    let intEndDay = date1.getDay();       // StartDate in Number Format like 0 for Sunday and 1 for Monday.
                                    let intEndMonth = date1.getMonth();   // StartMonth in Number Format like 0 for January and 11 for December.

                                    let toString = "To - " + daysNames[intEndDay] + "," + endDate + " " + monthNames[intEndMonth] + " " + endYear + "  -  " + endHours + ":" + endMins;
                                    let detailofaddorsub = " Added => " + numOfDays + " Business Days. ";
                                    let totalresult = daysNames[intEndDay] + "," + endDate + " " + monthNames[intEndMonth] + " " + endYear;

                                    $("#tostring").text(toString);
                                    $("#detailsofaddorsub").text(detailofaddorsub);
                                    $("#totaldaysresult").text(totalresult);

                                    return date1;
                                }
                                addDays(date1, 1);
                            }
                        }
                    }
                    ExcludeWeekend(date1, numOfDays);

                    $("#result").removeClass("d-none");
                    window.scrollTo(0, 760);

                }

                else {

                    $("#fromstring").text("");
                    $("#tostring").text("");
                    $("#detailsofaddorsub").text("");
                    $("#totaldaysresult").text("");
                    $("#fromstring").text(fromString);


                    //const addNewDate3 = addDays(date1, parseInt(numOfDays));
                    function ExcludeWeekend(date1, n) {
                        let count = 0;
                        for (var i = 0; n * 1.5; i++) {
                            if ((holidayDates.includes(date1) == true)) {
                                subDays(date1, 1);
                            }
                            else {
                                count++;
                                if (count == n) {

                                    let endDate = date1.getDate();            // return Start Date only like dd in dd/mm/yyyy format. 
                                    let endMonth = date1.getMonth() + 1;      // return Start Month only like mm in dd/mm/yyyy format. 
                                    let endYear = date1.getFullYear();        // return Start year only like yyyy in dd/mm/yyyy format.
                                    let endHours = date1.getHours();          // return Start Hours of Time Selection.
                                    let endMins = date1.getMinutes();         // return Start Minutes of Time Selection.

                                    let intEndDay = date1.getDay();       // StartDate in Number Format like 0 for Sunday and 1 for Monday.
                                    let intEndMonth = date1.getMonth();   // StartMonth in Number Format like 0 for January and 11 for December.




                                    let toString = "To - " + daysNames[intEndDay] + "," + endDate + " " + monthNames[intEndMonth] + " " + endYear + "  -  " + endHours + ":" + endMins;
                                    let detailofaddorsub = " Subtracted => " + numOfDays + " Business Days. ";
                                    let totalresult = daysNames[intEndDay] + "," + endDate + " " + monthNames[intEndMonth] + " " + endYear;

                                    $("#tostring").text(toString);
                                    $("#detailsofaddorsub").text(detailofaddorsub);
                                    $("#totaldaysresult").text(totalresult);
                                    return date1;
                                }
                                subDays(date1, 1);
                            }
                        }
                    }

                    ExcludeWeekend(date1, numOfDays);

                    $("#result").removeClass("d-none");
                    window.scrollTo(0, 760);

                }
            }

            else if ((document.getElementById("excludeweekend").checked == 1) && (document.getElementById("excludeholidays").checked == 1)) {

                if (addOrSubtract == 1) {

                    $("#fromstring").text("");
                    $("#tostring").text("");
                    $("#detailsofaddorsub").text("");
                    $("#totaldaysresult").text("");
                    $("#fromstring").text(fromString);

                    //const addNewDate3 = addDays(date1, parseInt(numOfDays));
                    function ExcludeWeekend(date1, n) {
                        let count = 0;
                        for (var i = 0; n * 1.5; i++) {
                            if ((date1.getDay() == 0) || (date1.getDay() == 6) || (holidayDates.includes(date1) == true)) {
                                addDays(date1, 1);
                            }
                            else {
                                count++;
                                if (count == n) {

                                    let endDate = date1.getDate();            // return Start Date only like dd in dd/mm/yyyy format. 
                                    let endMonth = date1.getMonth() + 1;      // return Start Month only like mm in dd/mm/yyyy format. 
                                    let endYear = date1.getFullYear();        // return Start year only like yyyy in dd/mm/yyyy format.
                                    let endHours = date1.getHours();          // return Start Hours of Time Selection.
                                    let endMins = date1.getMinutes();         // return Start Minutes of Time Selection.

                                    let intEndDay = date1.getDay();       // StartDate in Number Format like 0 for Sunday and 1 for Monday.
                                    let intEndMonth = date1.getMonth();   // StartMonth in Number Format like 0 for January and 11 for December.

                                    let toString = "To - " + daysNames[intEndDay] + "," + endDate + " " + monthNames[intEndMonth] + " " + endYear + "  -  " + endHours + ":" + endMins;
                                    let detailofaddorsub = " Added => " + numOfDays + " Business Days. ";
                                    let totalresult = daysNames[intEndDay] + "," + endDate + " " + monthNames[intEndMonth] + " " + endYear;

                                    $("#tostring").text(toString);
                                    $("#detailsofaddorsub").text(detailofaddorsub);
                                    $("#totaldaysresult").text(totalresult);

                                    return date1;
                                }
                                addDays(date1, 1);
                            }
                        }
                    }
                    ExcludeWeekend(date1, numOfDays);

                    $("#result").removeClass("d-none");
                    window.scrollTo(0, 760);

                }

                else {

                    $("#fromstring").text("");
                    $("#tostring").text("");
                    $("#detailsofaddorsub").text("");
                    $("#totaldaysresult").text("");
                    $("#fromstring").text(fromString);


                    //const addNewDate3 = addDays(date1, parseInt(numOfDays));
                    function ExcludeWeekend(date1, n) {
                        let count = 0;
                        for (var i = 0; n * 1.5; i++) {
                            if ((date1.getDay() == 0) || (date1.getDay() == 6) || (holidayDates.includes(date1) == true)) {
                                subDays(date1, 1);
                            }
                            else {
                                count++;
                                if (count == n) {

                                    let endDate = date1.getDate();            // return Start Date only like dd in dd/mm/yyyy format. 
                                    let endMonth = date1.getMonth() + 1;      // return Start Month only like mm in dd/mm/yyyy format. 
                                    let endYear = date1.getFullYear();        // return Start year only like yyyy in dd/mm/yyyy format.
                                    let endHours = date1.getHours();          // return Start Hours of Time Selection.
                                    let endMins = date1.getMinutes();         // return Start Minutes of Time Selection.

                                    let intEndDay = date1.getDay();       // StartDate in Number Format like 0 for Sunday and 1 for Monday.
                                    let intEndMonth = date1.getMonth();   // StartMonth in Number Format like 0 for January and 11 for December.




                                    let toString = "To - " + daysNames[intEndDay] + "," + endDate + " " + monthNames[intEndMonth] + " " + endYear + "  -  " + endHours + ":" + endMins;
                                    let detailofaddorsub = " Subtracted => " + numOfDays + " Business Days. ";
                                    let totalresult = daysNames[intEndDay] + "," + endDate + " " + monthNames[intEndMonth] + " " + endYear;

                                    $("#tostring").text(toString);
                                    $("#detailsofaddorsub").text(detailofaddorsub);
                                    $("#totaldaysresult").text(totalresult);
                                    return date1;
                                }
                                subDays(date1, 1);
                            }
                        }
                    }

                    ExcludeWeekend(date1, numOfDays);

                    $("#result").removeClass("d-none");
                    window.scrollTo(0, 760);

                }
            }

            else {
                Swal.fire({
                    icon: 'error',
                    title: 'Oops...',
                    html: '<div><h3>Please Select Atleast One Exclusion Check</h3><small style="color:red;">Exclusion Check Cannot Be Unchecked Before Calculation!</small></div>',

                })
            }
        }
        //#endregion














    }

    // Module no. 5 - WeekDays.
    function WeekDay() {


        //alert("Enetered WeekDay");

        var numOfDays = document.getElementById("inputdaysadd").value;
        var numOfMonths = document.getElementById("inputmonthsadd").value;
        var numOfYears = document.getElementById("inputyearsadd").value;

        if (numOfDays == "" || numOfMonths == "" || numOfYears == "") {
            Swal.fire({
                icon: 'error',
                title: 'Oops...',
                html: '<div><h3>Please Enter Days, Months & Year!</h3><small style="color:red;">Days, Months & Year fiels cannot be blank!</small></div>',
                //html: '',
            })
        }
        else {
            let weekdate = new Date(numOfYears, numOfMonths - 1, numOfDays);
            let endDate = weekdate.getDate();              // return End Date only like dd in dd/mm/yyyy format.
            let endMonth = weekdate.getMonth() + 1;        // return End Month only like mm in dd/mm/yyyy format.
            let endYear = weekdate.getFullYear();          // return Start Year only like yyyy in dd/mm/yyyy format.
            let endHours = weekdate.getHours();            // return End Hours of Time Selection.     
            let endMins = weekdate.getMinutes();           // return End Minutes of Time Selection.

            let intEndDay = weekdate.getDay();         // EndDate in Number Format like 0 for Sunday and 1 for Monday.
            let intEndMonth = weekdate.getMonth();     // EndMonth in Number Format like 0 for January and 11 for December.
            let totalresult = endDate + " " + monthNames[intEndMonth] + " " + endYear + " is a " + daysNames[intEndDay];

            $("#totaldaysresult").text(totalresult);


            $("#result").removeClass("d-none");
            window.scrollTo(0, 760);
        }
    }

    // Module no. 6 - WeekNo.
    function WeekNo() {


        //alert("Enetered WeekDay");


        if (startdateinput.value == "") {
            Swal.fire({
                icon: 'error',
                title: 'Oops...',
                html: '<div><h3>Please Enter Days, Months & Year!</h3><small style="color:red;">Days, Months & Year fiels cannot be blank!</small></div>',
                //html: '',
            })
        }
        else {

            var year = new Date(date1.getFullYear(), 0, 1);
            var days = Math.floor((date1 - year) / (24 * 60 * 60 * 1000));
            var week = Math.ceil((date1.getDay() + 1 + days) / 7);
            console.log("Week Number of the current date (" + date1 + ") is : " + week);


            let totalresult = daysNames[intStartDay] + " " + startDate + " " + monthNames[intStartMonth] + " " + startYear;
            let totalresult2 = "The Week Number of " + totalresult + " is => " + week;
            $("#totaldaysresult").text(totalresult2);


            $("#result").removeClass("d-none");
            window.scrollTo(0, 760);
        }
    }
    //#endregion
}








